Avant Slot — POPULATED CATEGORY PACK — RESEARCHED EUR EDITION
Prepared: 17 November 2026

180 product entries; 11 populated JSON files. Empty categories are omitted from the ZIP (all 19 files, including empty ones, remain in the folder next to the ZIP).
180 published EUR prices; 0 clearly labelled EUR estimates. All entries have a price object.

Read RESEARCH-REPORT.txt for sources, coverage decisions and access limits. PRICE-LIST.txt lists every EUR price. REVIEW-NOTES.txt indexes rows needing manual review.

Only the .json files are import files; .txt files are reports. No changes have been made inside Paddock.

FILES
part-axles-bearings.json: 22 products
part-body-interior.json: 27 products
part-chassis-mounting.json: 25 products
part-gears-transmission.json: 27 products
part-guides-pickups.json: 7 products
part-motors-motor-parts.json: 4 products
part-other-custom-parts.json: 0 products
part-screws-fixings.json: 11 products
part-suspension-handling.json: 8 products
part-tyres.json: 14 products
part-wheels-accessories.json: 32 products
part-wiring-electronics.json: 3 products
supply-adhesives-consumables.json: 0 products
supply-cleaning-lubrication.json: 0 products
supply-hand-tools.json: 0 products
supply-measuring-setup-tools.json: 0 products
supply-motor-electrical-equipment.json: 0 products
supply-storage-transport.json: 0 products
supply-tyre-wheel-equipment.json: 0 products

PRICING LOCATION
products[].price.amount — numeric amount
products[].price.currency — EUR
products[].price.status — published or estimate
products[].price.basis — pack, piece or item
products[].price.explanation — source/basis, tax and shipping notes
products[].price.sourceUrl and checkedDate — quotation/comparator provenance

OMITTED EMPTY FILES (from ZIP)
part-other-custom-parts.json
supply-adhesives-consumables.json
supply-cleaning-lubrication.json
supply-hand-tools.json
supply-measuring-setup-tools.json
supply-motor-electrical-equipment.json
supply-storage-transport.json
supply-tyre-wheel-equipment.json
