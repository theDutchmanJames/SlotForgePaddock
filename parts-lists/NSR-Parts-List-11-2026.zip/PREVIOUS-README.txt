SLOTFORGE — NSR — 19 CATEGORY FILES
Prepared: 14 November 2026. Product descriptions: British English. Price currency: EUR.

19 separate import JSON files; 1237 product entries. Brand kept separate throughout. Original template format, version, instructions, reference guidance and examples are unchanged.

FILE COUNTS
part-axles-bearings.json: 66
part-body-interior.json: 172
part-chassis-mounting.json: 213
part-gears-transmission.json: 171
part-guides-pickups.json: 19
part-motors-motor-parts.json: 58
part-other-custom-parts.json: 0
part-screws-fixings.json: 33
part-suspension-handling.json: 32
part-tyres.json: 257
part-wheels-accessories.json: 167
part-wiring-electronics.json: 11
supply-adhesives-consumables.json: 0
supply-cleaning-lubrication.json: 9
supply-hand-tools.json: 17
supply-measuring-setup-tools.json: 6
supply-motor-electrical-equipment.json: 0
supply-storage-transport.json: 5
supply-tyre-wheel-equipment.json: 1

RESEARCH COVERAGE
Current manufacturer family pages and variant selectors, the 2026 manufacturer catalogue, earlier retailer research and all 45 paginated Slot Car-Union spares/tools/fluids listings were checked.
Coverage is of the accessible cited sources, including historical items; it is not a claim that every discontinued part ever produced is documented online. Some retailer product pages were inaccessible or available only through indexed listings; affected rows explain this. Manufacturer tables/PDFs serve as sources when no individual product page is available. Unknown measurements, packs and compatibility remain unfilled.

RETAILER LISTING AUDIT
https://www.slotcar-union.com/en/340-spare-parts — 43 page(s)
https://www.slotcar-union.com/en/341-tools — 1 page(s)
https://www.slotcar-union.com/en/358-performance-fluids — 1 page(s)

TYRES
257 loose-tyre/tyre-blank entries; 86 mounted wheel-and-tyre sets in part-wheels-accessories.json.
Special RTR: 42
Low-grip sponge: 1
Zero Graining: 23
Ultragrip: 64
Supergrip: 69
High-grip fish rubber: 1
No Friction: 31
Ready to Race: 1
Extreme: 23
Sponge: 1
Soft sponge: 1
Only published reference/size/compound combinations are included. Missing dimensions are not inferred from another compound. Separate pack and stiffness variants retain their identities.

PRICING
1041 published quotations; 196 clearly labelled estimates.
Published prices are for the stated retail item or pack; tax and shipping treatment are explained. Estimates cite a comparable reference where available, otherwise a rounded budget basis. Estimates are not verified retail offers. Historical products may no longer be purchasable.

REVIEW
Two products lack a manufacturer reference: Hypercar progressive-suspension cups and medium progressive springs. Check these manually before matching stock. Tyre dimensions remain unresolved for 5266R/S/U. Several motor-pod, motor, gear, axle and wheel descriptions conflict with selectors or catalogue tables; see individual reviewNotes. Reference 1208 has a manufacturer/retailer pack-count conflict and its quoted price is explicitly for the retailer pack.
52 entries have a blank partType because the supplied type list has no precise supported match. Their known categories and specific reasons remain available for review.
2 entries have no confirmed reference. No invented SKU is used.

EMPTY SCOPES
part-other-custom-parts.json
supply-adhesives-consumables.json
supply-motor-electrical-equipment.json
Empty scopes indicate no matching product verified in the sources checked, not proof that the manufacturer never offered one.

VALIDATION
All 38 files across the two brand packs passed required-field, allowed classification, manufacturer isolation, source/date, duplicate reference, specification shape and EUR price validation. Each nonblank manufacturer/reference occurs once per brand. These checks cannot resolve conflicting source facts.

IMPORT
Extract this brand ZIP into its own folder; filenames are intentionally identical between manufacturers. Import the 19 JSON files into SlotForge. README.txt and REVIEW-NOTES.txt are reports, not import files. On import review screens, use Show more when available to display additional entries. No import or change inside Paddock has been performed.

EXCLUSIONS
Complete cars, track sections and promotional apparel/gadgets are outside these 19 scopes. Sold assemblies remain one product; their contents do not create invented component references. Stock ownership, purchase quantities and photographs are not included.
