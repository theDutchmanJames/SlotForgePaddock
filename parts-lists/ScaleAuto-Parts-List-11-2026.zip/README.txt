Scaleauto — POPULATED CATEGORY PACK — RESEARCHED EUR EDITION
Prepared: 15 November 2026

1401 product entries; 18 populated JSON files. Empty categories omitted from this ZIP at the user's request. No catalogue product was removed.
569 published EUR prices; 832 clearly labelled EUR estimates. All entries have a price object.
This package contains the latest researched products and EUR prices, with empty JSON files excluded. Research reports document all 19 categories checked; their references to retaining empty files describe the full research edition, not this populated-only ZIP.

Read RESEARCH-REPORT.txt for sources, category-by-category decisions, corrections and access limits. PRICE-LIST.txt lists every EUR price. PREVIOUS-README.txt preserves the earlier broader research history; this report takes precedence for today’s corrections.

Extract each manufacturer into a separate folder. Only the 18 .json files are import files; .txt files are reports. No changes have been made inside Paddock.

FILES
part-axles-bearings.json: 87 products
part-body-interior.json: 221 products
part-chassis-mounting.json: 312 products
part-gears-transmission.json: 199 products
part-guides-pickups.json: 52 products
part-motors-motor-parts.json: 42 products
part-other-custom-parts.json: 0 products
part-screws-fixings.json: 66 products
part-suspension-handling.json: 30 products
part-tyres.json: 97 products
part-wheels-accessories.json: 154 products
part-wiring-electronics.json: 9 products
supply-adhesives-consumables.json: 13 products
supply-cleaning-lubrication.json: 19 products
supply-hand-tools.json: 34 products
supply-measuring-setup-tools.json: 15 products
supply-motor-electrical-equipment.json: 12 products
supply-storage-transport.json: 32 products
supply-tyre-wheel-equipment.json: 7 products

PRICING LOCATION
products[].price.amount — numeric amount
products[].price.currency — EUR
products[].price.status — published or estimate
products[].price.basis — pack, piece or item
products[].price.explanation — source/basis, tax and shipping notes
products[].price.sourceUrl and checkedDate — quotation/comparator provenance

OMITTED EMPTY FILES
part-other-custom-parts.json

