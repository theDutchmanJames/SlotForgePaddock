SLOTFORGE — SCALEAUTO — 19 CATEGORY FILES
Prepared: 14 November 2026. Product descriptions: British English. Price currency: EUR.

19 separate import JSON files; 1401 product entries. Brand kept separate throughout. Original template format, version, instructions, reference guidance and examples are unchanged.

FILE COUNTS
part-axles-bearings.json: 87
part-body-interior.json: 221
part-chassis-mounting.json: 312
part-gears-transmission.json: 199
part-guides-pickups.json: 52
part-motors-motor-parts.json: 42
part-other-custom-parts.json: 0
part-screws-fixings.json: 66
part-suspension-handling.json: 30
part-tyres.json: 97
part-wheels-accessories.json: 154
part-wiring-electronics.json: 9
supply-adhesives-consumables.json: 13
supply-cleaning-lubrication.json: 19
supply-hand-tools.json: 34
supply-measuring-setup-tools.json: 15
supply-motor-electrical-equipment.json: 12
supply-storage-transport.json: 32
supply-tyre-wheel-equipment.json: 7

RESEARCH COVERAGE
The 63 official parts/tools catalogue panels were re-fetched and checked; 54 official model technical sheets were compared for additional references, with visual review of ambiguous/new entries. The motor-tester manual and official announcements were also checked. All 25 Slot Car-Union spares/tools/fluids/storage listing pages were checked, alongside earlier specialist-retailer research.
Coverage is of the accessible cited sources, including historical items; it is not a claim that every discontinued part ever produced is documented online. Some retailer product pages were inaccessible or available only through indexed listings; affected rows explain this. Manufacturer tables/PDFs serve as sources when no individual product page is available. Unknown measurements, packs and compatibility remain unfilled.

RETAILER LISTING AUDIT
https://www.slotcar-union.com/en/326-spare-parts — 21 page(s)
https://www.slotcar-union.com/en/280-tools — 2 page(s)
https://www.slotcar-union.com/en/301-performance-fluids — 1 page(s)
https://www.slotcar-union.com/en/522-storage-carrying — 1 page(s)

TYRES
97 loose-tyre/tyre-blank entries; 73 mounted wheel-and-tyre sets in part-wheels-accessories.json.
Standard: 8
RT: 14
Shore 30: 4
Zero Grip: 4
Soft: 7
Medium: 4
AS20: 11
AS25: 14
IS22: 2
Procomp: 14
Procomp 4: 5
Procomp 3: 3
Hardcomp: 1
Procomp 2: 5
AS30: 1
Only published reference/size/compound combinations are included. Missing dimensions are not inferred from another compound. Separate pack and stiffness variants retain their identities.

PRICING
569 published quotations; 832 clearly labelled estimates.
Published prices are for the stated retail item or pack; tax and shipping treatment are explained. Estimates cite a comparable reference where available, otherwise a rounded budget basis. Estimates are not verified retail offers. Historical products may no longer be purchasable.

REVIEW
SC-3650 is printed against different body models in official technical sheets; it is included once with the conflict noted. SC-4721H30 and SC-8104D are inconsistent labels in technical sheets, documented on SC-4721SH30 and SC-8170D rather than invented as new products. SC-0011 is retained as an unsuffixed catalogue reference, distinct from B/C versions. Other dimensions, pack and compatibility uncertainties are documented per product.
51 entries have a blank partType because the supplied type list has no precise supported match. Their known categories and specific reasons remain available for review.
0 entries have no confirmed reference. No invented SKU is used.

EMPTY SCOPES
part-other-custom-parts.json
Empty scopes indicate no matching product verified in the sources checked, not proof that the manufacturer never offered one.

VALIDATION
All 38 files across the two brand packs passed required-field, allowed classification, manufacturer isolation, source/date, duplicate reference, specification shape and EUR price validation. Each nonblank manufacturer/reference occurs once per brand. These checks cannot resolve conflicting source facts.

IMPORT
Extract this brand ZIP into its own folder; filenames are intentionally identical between manufacturers. Import the 19 JSON files into SlotForge. README.txt and REVIEW-NOTES.txt are reports, not import files. On import review screens, use Show more when available to display additional entries. No import or change inside Paddock has been performed.

EXCLUSIONS
Complete cars, track sections and promotional apparel/gadgets are outside these 19 scopes. Sold assemblies remain one product; their contents do not create invented component references. Stock ownership, purchase quantities and photographs are not included.
