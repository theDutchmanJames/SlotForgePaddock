SlotForge Slot.it catalogue kits — researched 14 November 2026

DELIVERY
814 unique manufacturer references across 19 separate JSON files. Slot.it only. No complete cars or Policar-branded products are included. Original template format, version, instructions, reference data and examples are preserved. Only products and coverageNotes were populated.
These are catalogue proposals for review/import; no changes were made to Paddock or the original Desktop kits.

COUNTS
part-axles-bearings.json: 32
part-body-interior.json: 208
part-chassis-mounting.json: 120
part-gears-transmission.json: 146
part-guides-pickups.json: 15
part-motors-motor-parts.json: 10
part-other-custom-parts.json: 0
part-screws-fixings.json: 29
part-suspension-handling.json: 19
part-tyres.json: 67
part-wheels-accessories.json: 85
part-wiring-electronics.json: 22
supply-adhesives-consumables.json: 0
supply-cleaning-lubrication.json: 3
supply-hand-tools.json: 14
supply-measuring-setup-tools.json: 0
supply-motor-electrical-equipment.json: 41
supply-storage-transport.json: 3
supply-tyre-wheel-equipment.json: 0

PRICES
728 exact-reference published EUR prices; 86 explicitly labelled estimates. Prices represent retail items/packs, not ownership or purchase records.
Published prices were obtained from Slot Car-Union listings or product pages on 2026-11-14. The source URL points to the page actually checked, and the explanation identifies the exact product URL. TTC prices include tax as shown by the retailer; shipping is excluded. Your location/tax settings may change a subsequent displayed price.
Estimates state their comparable reference and calculation, or explicitly state that they are broad budget estimates with no matching quotation. These estimates are not confirmed offers. The SCP301fg estimate uses an indexed exact-reference quote because direct access to that retailer was challenged.
Some retailer pack quantities differ from manufacturer quantities. Those conflicts are explicitly stated; do not compare the stated retailer price as if it covered the manufacturer pack.

SOURCES AND COVERAGE
The current manufacturer English sitemap contained 1,151 product URLs. After filtering complete cars/other brands/promotional material, 727 candidates were checked: 711 parts/equipment pages, 15 excluded car/non-Slot.it pages and one broken product page. Separate historical/PDF/retailer references supplement these pages.
Manufacturer catalogue: https://slot.it/wp-content/uploads/2024/12/SLOT.IT-SPAREPARTS-2025-web-ok-1.pdf
Manufacturer product site: https://catalog.slot.it/
Manufacturer tyre reference: https://slot.it/wp-content/uploads/2020/02/WheelTyreCrossList.en_.pdf
Historical tyre dimensions: https://www.pendleslotracing.co.uk/downloads/slot-it-tyres-chart.pdf
Retailer lists: https://www.slotcar-union.com/en/77-spare-parts (28 pages), /en/279-tools, /en/328-performance-fluids, /en/94-controllers-digital-chips and /en/287-digital-chips.
The 2025 manufacturer PDF was downloaded again and matched the previously extracted file exactly (SHA-256 ffcfffa924becc9378971121a185cb9cfede54c86ab1037ab0f4c5b2e4f071a2). Relevant illustrated pages were inspected to check tyres, conversion kits, axles and grub screws.
769 product records have source checks dated 2026-11-14. The 45 supplementary records checked on 2026-11-13 retain that date rather than falsely claiming a new product-page check. All published price checks are dated 2026-11-14.
This covers the identified references in those sources, including historical references; it is not a guarantee that every part ever made or every future release is present. Current stock/production status is not asserted merely because a page exists.

TYRES
67 references, including current and historical/renamed codes. Compound, mould/drawing code and nominal diameter/width are separate specifications where verified. G25: PT1207G25, PT1171G25, PT1172G25, PT1323G25. C1, S1, S2, SP25, SP30, F22 and documented historical compounds are included.
Renamed references are retained as separate reference identities and are not necessarily different physical tyres. PT9670E1 is documented in an ambiguous historical cross-reference table, so its nominal dimensions remain unresolved instead of being guessed.
Conflicting 1323 nominal diameters, historical 1028 widths and C1 pack quantities are noted per product. Mounted diameter is not silently substituted for nominal tyre diameter.

CLASSIFICATION AND SOURCE LIMITS
77 products have a known category but no exact supported partType. The subtype is deliberately blank and each has a review note. These include controller components, pinion tools and some multi-component kits.
Motor-pod conversion kits KK11, KK10c, KK13b, KK12b, KK14d and KK16b are Motor pod products with catalogue-confirmed contents; the older KK14c revision is kept distinct.
The manufacturer SP15d product page returned 404. SP15d was recovered from the official PDF and exact-reference retailer page. SP15c1 is retained separately.
The manufacturer KK17b heading is "None"; its actual description/category supplied the name. MN14h has a 24,000 rpm web-page rating versus 25,000 rpm in the PDF; the current web rating is retained with a conflict note.
The historical Pendle chart returned HTTP 403 on direct download, but its PDF text was accessible and checked through the web PDF reader.

EMPTY FILES
part-other-custom-parts.json: No separately verified Slot.it part belonged in Other / custom parts. Products with a known function but no supported subtype remain in their functional category with blank partType and an explanatory review note.
supply-adhesives-consumables.json: No separately sold Slot.it-branded adhesive, tape, solder, flux, heat-shrink, abrasive or paint reference was identified in the checked manufacturer catalogue and retailer listings.
supply-measuring-setup-tools.json: No separately sold Slot.it-branded measuring/setup tool matching this scope was identified. PA47/PA52 spacer frets remain in Axles & bearings; no separate measuring-tool SKU was invented.
supply-tyre-wheel-equipment.json: No separately sold Slot.it-branded tyre truer, wheel puller, balancer or other matching equipment was identified. Slot.it pinion presses/pullers and their spares are in Hand tools; they are not wheel pullers.

VALIDATION
All 19 JSON files parse. Required fields, enums, template preservation, category scope, unique case-insensitive manufacturer references, specification types, prices and dates were checked. No validation errors or warnings remain. Required G25/C1/SP compound references and motor-pod kit references passed explicit coverage checks.
REVIEW-NOTES.txt collects the per-product review notes and estimated prices. Review them during import.
