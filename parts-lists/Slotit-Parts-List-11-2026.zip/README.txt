Slot.it — POPULATED CATEGORY PACK — RESEARCHED EUR EDITION
Prepared: 15 November 2026

814 product entries; 15 populated JSON files. Empty categories omitted from this ZIP at the user's request. No catalogue product was removed.
728 published EUR prices; 86 clearly labelled EUR estimates. All entries have a price object.
This package contains the latest researched products and EUR prices, with empty JSON files excluded. Research reports document all 19 categories checked; their references to retaining empty files describe the full research edition, not this populated-only ZIP.

Read RESEARCH-REPORT.txt for sources, category-by-category decisions, corrections and access limits. PRICE-LIST.txt lists every EUR price. PREVIOUS-README.txt preserves the earlier broader research history; this report takes precedence for today’s corrections.

Extract each manufacturer into a separate folder. Only the 15 .json files are import files; .txt files are reports. No changes have been made inside Paddock.

FILES
part-axles-bearings.json: 32 products
part-body-interior.json: 208 products
part-chassis-mounting.json: 120 products
part-gears-transmission.json: 146 products
part-guides-pickups.json: 15 products
part-motors-motor-parts.json: 10 products
part-other-custom-parts.json: 0 products
part-screws-fixings.json: 29 products
part-suspension-handling.json: 19 products
part-tyres.json: 67 products
part-wheels-accessories.json: 85 products
part-wiring-electronics.json: 22 products
supply-adhesives-consumables.json: 0 products
supply-cleaning-lubrication.json: 3 products
supply-hand-tools.json: 14 products
supply-measuring-setup-tools.json: 0 products
supply-motor-electrical-equipment.json: 41 products
supply-storage-transport.json: 3 products
supply-tyre-wheel-equipment.json: 0 products

PRICING LOCATION
products[].price.amount — numeric amount
products[].price.currency — EUR
products[].price.status — published or estimate
products[].price.basis — pack, piece or item
products[].price.explanation — source/basis, tax and shipping notes
products[].price.sourceUrl and checkedDate — quotation/comparator provenance

OMITTED EMPTY FILES
part-other-custom-parts.json
supply-adhesives-consumables.json
supply-measuring-setup-tools.json
supply-tyre-wheel-equipment.json

